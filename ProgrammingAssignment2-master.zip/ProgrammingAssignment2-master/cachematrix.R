## This fucntion creates a special matrix object that can cache its inverse.

makeCacheMatrix <- function(x = matrix()) { #the x here is matrix that the makeCacheMatrix will take
      object <- NULL
      set <- function(y){   #another function(nested funtion) that is used to assign value of the
        x <<- y             #matrix in another environment using <<-.x <<- y    
}
get <- function() x  #this gets the value of our matrix
setInverse <- function(inverse) object <<- inverse #sets the value of the inverse of our matrix and stick 
                                                  #to another environment called inverse
getInverse <- function() object #This gets the inverse of our matrix                  
list(set = set, get = get, 
     setInverse = setInverse,
     getInverse = getInverse)
}

##this computes the inverse of a special matrix returned by the above function. If the inverse has already 
##been calculated, and the matrix is still the same, then this function will just go and just take the inverse from
## the cached inverse
cacheSolve <- function(x, ...) {
  ## Return a matrix that is the inverse of 'x'
  object <- x$getInverse()#this takes the inverse from the above function--the matrix inverse you already calculated  
  if(!is.null(object)){ #if the inverse has already been calculated then get it from the saved(cached) data
    message("getting cached data") 
    return(object) 
  }
  mat <- x$get()
  object <- solve(mat,...) #Creates the matrix if it has not already been created
  x$setInverse(object)     
  object               # and prints it out.
}
